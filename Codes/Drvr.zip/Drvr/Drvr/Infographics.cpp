#include "Infographics.h"
#include <iostream>
#include <fstream>
#include <Windows.h>
#include <wincon.h>
#include <sstream>
#include <vector>
#include <list>

using namespace std;
using namespace System;
using namespace System::ComponentModel;
using namespace System::Collections;
using namespace System::Collections::Generic;
using namespace System::Windows::Forms;
using namespace System::Data;
using namespace System::Drawing;


void Drvr::Infographics::calculateNeededButtons()
	{
		
		int value = 8;
		int topRow = 0;		// initiate top and bottom row values to calculate.
		int bottomRow = 0;
		


		if (value % 2 == 0) // value is even
		{
			if (value < 4)
			{
				topRow = value;
			}
			else if (value >= 4)
			{
				topRow = value / 2;
				bottomRow = value / 2;

			}
			

		}
		
		else if (value % 2 != 0)// value is uneven
		{

			if (value < 4)
			{
				topRow = value;
			}
			else if (value >= 5)
			{
				topRow = (value / 2) + 1;
				bottomRow = value / 2;
			}
		}


		//********************************* Top Row Button Mapping *********************************
		if (topRow == 2)
		{
			top7Components->Location = Point(114, 30);
			b3Top7->Visible = true;
			b4Top7->Visible = true;
		}
		else if (topRow == 3)
		{
			b3Top7->Visible = true;
			b4Top7->Visible = true;
			b5Top7->Visible = true;
		}
		else if (topRow == 4)
		{
			top7Components->Location = Point(114, 30);
			b2Top7->Visible = true;
			b3Top7->Visible = true;
			b4Top7->Visible = true;
			b5Top7->Visible = true;
		}
		else if (topRow == 5)
		{
			b2Top7->Visible = true;
			b3Top7->Visible = true;
			b4Top7->Visible = true;
			b5Top7->Visible = true;
			b6Top7->Visible = true;
		}
		else if (topRow == 6)
		{
			top7Components->Location = Point(114, 30);
			b1Top7->Visible = true;
			b2Top7->Visible = true;
			b3Top7->Visible = true;
			b4Top7->Visible = true;
			b5Top7->Visible = true;
			b6Top7->Visible = true;
		}
		else if (topRow == 7)
		{
			b1Top7->Visible = true;
			b2Top7->Visible = true;
			b3Top7->Visible = true;
			b4Top7->Visible = true;
			b5Top7->Visible = true;
			b6Top7->Visible = true;
			b7Top7->Visible = true;
		}

		//******************************************************************************************
		//********************************* Bottom Row Button Mapping *********************************
		if (bottomRow == 1)
		{
			b1Btm7->Visible = true;
		}
		else if (bottomRow == 2)
		{
			btm7Components->Location = Point(114, 430);
			b3Btm7->Visible = true;
			b4Btm7->Visible = true;
		}
		else if (bottomRow == 3)
		{
			b3Btm7->Visible = true;
			b4Btm7->Visible = true;
			b5Btm7->Visible = true;
		}
		else if (bottomRow == 4)
		{
			btm7Components->Location = Point(114, 430);
			b2Btm7->Visible = true;
			b3Btm7->Visible = true;
			b4Btm7->Visible = true;
			b5Btm7->Visible = true;
		}
		else if (bottomRow == 5)
		{
			b2Btm7->Visible = true;
			b3Btm7->Visible = true;
			b4Btm7->Visible = true;
			b5Btm7->Visible = true;
			b6Btm7->Visible = true;
		}
		else if (bottomRow == 6)
		{
			btm7Components->Location = Point(114, 430);
			b1Btm7->Visible = true;
			b2Btm7->Visible = true;
			b3Btm7->Visible = true;
			b4Btm7->Visible = true;
			b5Btm7->Visible = true;
			b6Btm7->Visible = true;
		}
		else if (bottomRow == 7)
		{
			b1Btm7->Visible = true;
			b2Btm7->Visible = true;
			b3Btm7->Visible = true;
			b4Btm7->Visible = true;
			b5Btm7->Visible = true;
			b6Btm7->Visible = true;
			b7Btm7->Visible = true;
		}
	
}


void Drvr::Infographics::test()
{
	//System::String^ a = "hallelujah";

	
	List<Button^> meh;
	meh.Add(b1Btm7);
	btm7Components->Visible = true;
	meh[0]->Visible = true;
	meh[0]->Text = "haha";

	
	
	


	

}
